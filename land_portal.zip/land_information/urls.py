from django.urls import path
from .views import PopularNewsView

urlpatterns = [
    path(r'index', PopularNewsView.as_view(), name='index'), # as_view() 클래스 함수를 통해 함수뷰 생성
]