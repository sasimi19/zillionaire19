from django.shortcuts import render
from django.views.generic import ListView
from .models import PopularNews

class PopularNewsView(ListView):
	model = PopularNews

	
