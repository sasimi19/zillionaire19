from django.db import models
from imagekit.models import ProcessedImageField
from imagekit.processors import ResizeToFill

class PopularNews(models.Model):
	title = models.CharField(max_length = 255)
	#description = models.CharField(max_Langth = 1000)
	photo_thumbnail = ProcessedImageField(
					upload_to ="land_information/popularnews",
					processors = [ResizeToFill(100,100)], #Thumbnail
					format ='JPEG',
					options = {'quality' : 60})
		
	def __str__(self):
		return self.title
