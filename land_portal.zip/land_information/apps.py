from django.apps import AppConfig


class LandInformationConfig(AppConfig):
    name = 'land_information'
